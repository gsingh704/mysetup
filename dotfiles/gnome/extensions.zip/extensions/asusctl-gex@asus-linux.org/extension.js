const Config = imports.misc.config;
const ExtensionUtils = imports.misc.extensionUtils;
const Me = imports.misc.extensionUtils.getCurrentExtension();
const Log = Me.imports.modules.log;
const Supported = Me.imports.modules.supported;
const Profile = Me.imports.modules.profile;
const GfxMode = Me.imports.modules.gfx_mode;
const Charge = Me.imports.modules.charge;
const Anime = Me.imports.modules.anime;
const Panel = Me.imports.modules.panel;
var Extension = class Extension {
    constructor() {
    }
    enable() {
        this.isDebug = false;
        this.getGexSettings();
        Log.info(`Initializing ${Me.metadata.name} version ${Me.metadata.version} on GNOME Shell ${Config.PACKAGE_VERSION}`);
        this.supported = new Supported.Client();
        this.supported.start();
        this.profile = new Profile.Client();
        this.gfxMode = new GfxMode.Client();
        if (this.supported.connector.supportedAttributes.charge)
            this.chargingLimit = new Charge.Client();
        if (this.supported.connector.supportedAttributes.anime)
            this.anime = new Anime.Client();
        Log.info(`Enabling ${Me.metadata.name} version ${Me.metadata.version}`);
        this.panelButton = new Panel.AsusNb_Indicator();
        this.profile.start();
        this.gfxMode.start();
        if (this.supported.connector.supportedAttributes.charge)
            this.chargingLimit.start();
        if (this.supported.connector.supportedAttributes.anime)
            this.anime.start();
    }
    disable() {
        Log.info(`Disabling ${Me.metadata.name} version ${Me.metadata.version}`);
        this.supported.stop();
        this.profile.stop();
        this.gfxMode.stop();
        if (this.supported.connector.supportedAttributes.charge)
            this.chargingLimit.stop();
        if (this.supported.connector.supportedAttributes.anime)
            this.anime.stop();
        this.panelButton.destroy();
        this.panelButton = null;
    }
    getGexSettings() {
        try {
            this.settings = ExtensionUtils.getSettings();
            this.isDebug = this.getGexSetting('debug-enabled');
        }
        catch (e) {
            Log.debug('Error getting settings.', e);
        }
    }
    getGexSetting(setting) {
        try {
            return this.settings.get_boolean(setting);
        }
        catch (e) {
            return false;
        }
    }
}
function init() {
    ext = new Extension();
    return ext;
}
//# sourceMappingURL=extension.js.map