const Config = imports.misc.config;
const Me = imports.misc.extensionUtils.getCurrentExtension();
const { Gio } = imports.gi;
const Log = Me.imports.modules.log;
const Profile = Me.imports.modules.profile;
const GfxMode = Me.imports.modules.gfx_mode;
const Charge = Me.imports.modules.charge;
const Anime = Me.imports.modules.anime;
const Panel = Me.imports.modules.panel;
var Extension = class Extension {
    constructor() {
        this.panelButton = new Panel.Button();
        this.settings = null;
        Log.info(`Initializing ${Me.metadata.name} version ${Me.metadata.version} on GNOME Shell ${Config.PACKAGE_VERSION}`);
        this.getSettings();
        this.profile = new Profile.Client();
        this.gfxMode = new GfxMode.Client();
        this.chargingLimit = new Charge.Client();
        this.anime = new Anime.Client();
    }
    enable() {
        Log.info(`Enabling ${Me.metadata.name} version ${Me.metadata.version}`);
        this.panelButton.create();
        this.profile.start();
        this.gfxMode.start();
        this.chargingLimit.start();
        this.anime.start();
    }
    disable() {
        Log.info(`Disabling ${Me.metadata.name} version ${Me.metadata.version}`);
        this.profile.stop();
        this.gfxMode.stop();
        this.chargingLimit.stop();
        this.panelButton.destroy();
    }
    getSettings() {
        try {
            this.settings = new Gio.Settings({
                schema_id: 'org.asus-linux.gex',
            });
        }
        catch (error) {
            Log.error('Error getting settings, creating initials...', error);
        }
    }
}
function init() {
    ext = new Extension();
    return ext;
}
//# sourceMappingURL=extension.js.map