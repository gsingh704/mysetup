const Me = imports.misc.extensionUtils.getCurrentExtension();
const { main, popupMenu } = imports.ui;
const { Gio, GLib } = imports.gi;
const Log = Me.imports.modules.log;
const DBus = Me.imports.modules.gfx_mode_dbus;
var Client = class Client {
    constructor() {
        this.iGpuString = 'unknown';
        this.connector = new DBus.GfxMode();
        this.connected = false;
        Log.debug(`Starting GfxMode client...`);
    }
    getIGPU() {
        try {
            this.iGpuString = GLib.file_test('/sys/bus/pci/drivers/amdgpu', GLib.FileTest.EXISTS) ? 'amd' : 'intel';
        }
        catch (e) {
            this.iGpuString = 'intel';
        }
        Log.debug(`Detected integrated GPU: ${this.iGpuString}`);
        return this.iGpuString;
    }
    getAcl(ven, idx) {
        return this.connector.getAcl(ven, idx);
    }
    isRunning() {
        return (this.connected && this.connector && this.connector.isRunning());
    }
    start() {
        this.connected = this.connector.start();
        if (this.connected)
            this.populatePopup();
    }
    stop() {
        Log.debug(`Stopping GfxMode client...`);
        if (this.isRunning()) {
            this.connected = false;
            this.connector.stop();
        }
    }
    populatePopup() {
        if (this.isRunning() && this.connector.supported.length > 0) {
            ext.panelButton._indicatorLayout.add_child(ext.panelButton._binGpu);
            let vendor = this.connector.getGfxMode();
            let gpuPower = this.connector.getGpuPower();
            let menu = main.panel.statusArea['asusctl-gex.panel'].menu;
            let menuIdx = 1;
            menu.addMenuItem(new popupMenu.PopupMenuItem('Graphics Mode', { hover: false, can_focus: false, style_class: 'headline gfx headline-label asusctl-gex-menu-item' }), 0);
            Log.debug(`Current Graphics Mode is ${this.connector.gfxLabels[vendor]}`);
            if (typeof gpuPower !== 'undefined') {
                let gpuPowerItem = new popupMenu.PopupImageMenuItem(`dedicated GPU: ${this.connector.gfxLabels[gpuPower]}`, Gio.icon_new_for_string(`${Me.path}/icons/scalable/dgpu-${this.connector.gfxLabels[gpuPower]}.svg`), {
                    hover: false,
                    can_focus: false,
                    style_class: `gpupower ${this.connector.gfxLabels[gpuPower]} asusctl-gex-menu-item`
                });
                menu.addMenuItem(gpuPowerItem, menuIdx++);
                menu.addMenuItem(new popupMenu.PopupSeparatorMenuItem(), menuIdx++);
            }
            let indexIntegrated = 0;
            this.connector.supported.forEach((supported) => {
                menuIdx++;
                let localIndex = menuIdx;
                let labelMenu = this.connector.gfxLabels[supported];
                if (labelMenu == 'integrated') {
                    indexIntegrated = localIndex;
                }
                if (labelMenu == 'vfio' || labelMenu == 'compute') {
                    labelMenu = '↳ ' + labelMenu;
                    localIndex = indexIntegrated;
                }
                let menuItem = new popupMenu.PopupImageMenuItem(labelMenu, Gio.icon_new_for_string(`${Me.path}/icons/scalable/gpu-${this.connector.gfxLabels[supported]}.svg`), { style_class: `${this.connector.gfxLabels[supported]} gfx-mode ${this.iGpuString} asusctl-gex-menu-item` });
                let idx = this.connector.gfxLabels.indexOf(this.connector.gfxLabels[supported]);
                let acl = this.getAcl(vendor, idx);
                if (idx === vendor) {
                    menuItem.style_class = `${menuItem.style_class} active asusctl-gex-menu-item`;
                    menuItem.label.set_text(`${menuItem.label.text}  ✔`);
                }
                menu.addMenuItem(menuItem, localIndex);
                menuItem.sensitive = acl;
                menuItem.active = acl;
                menuItem.connect('activate', () => {
                    if (this.connector.lastState == 1 && idx == 3)
                        this.connector.pollerDelayTicks = 5;
                    this.connector.setGfxMode(idx);
                });
            });
            menu.addMenuItem(new popupMenu.PopupSeparatorMenuItem(), menuIdx++);
        }
    }
}
//# sourceMappingURL=gfx_mode.js.map