const Me = imports.misc.extensionUtils.getCurrentExtension();
const Log = Me.imports.modules.log;
const Panel = Me.imports.modules.panel;
const Resources = Me.imports.modules.resources;
const Gio = imports.gi.Gio;
var Profile = class Profile {
    constructor() {
        this.powerProfilesProxy = null;
        this.powerProfilesSignalProxy = null;
        this.connectedPPD = false;
        this.lastState = null;
        this.profiles = [];
    }
    getProfileNames() {
        if (this.isRunning()) {
            try {
                let _profiles = this.powerProfilesProxy.Profiles;
                if (_profiles.length > 0) {
                    for (const [_key, value] of Object.entries(_profiles)) {
                        this.profiles[parseInt(_key)] = {
                            'Profile': value.Profile.unpack(),
                            'Driver': value.Driver.unpack()
                        };
                        Log.debug(`Fetched Power Profile: ${value.Profile.unpack()}`);
                    }
                }
            }
            catch (e) {
                Log.error(`Power Profiles: failed to fetch profile names!`, e);
            }
        }
        return this.profiles;
    }
    setProfile(mode) {
        if (this.isRunning()) {
            try {
                this.powerProfilesProxy.ActiveProfile = mode;
                this.updateProfile(mode);
                return true;
            }
            catch (e) {
                Log.error(`Profile DBus set power profile failed!`, e);
                return false;
            }
        }
    }
    setProfileFromSignal(name = '', variant, profile = []) {
        if (this.isRunning()) {
            try {
                if (profile.length > 0) {
                    for (const [_key, value] of Object.entries(profile)) {
                        if (typeof value == 'object') {
                            for (const [_keyInner, valueInner] of Object.entries(value)) {
                                if (_keyInner == 'ActiveProfile') {
                                    let currentProfile = valueInner.print(true);
                                    currentProfile = currentProfile.replaceAll("'", '');
                                    this.updateProfile(currentProfile);
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            catch (e) {
                Log.error(`Power Profiles: failed to fetch profile names!`, e);
                return false;
            }
        }
    }
    updateProfile(curState = null) {
        Log.debug(curState);
        if (curState && curState !== '' && this.lastState !== curState) {
            let message = `Power profile has changed to ${curState}`;
            if (this.lastState !== null) {
                Panel.Actions.notify(Panel.Title, message, `scalable/notification-${curState}.svg`);
            }
            this.lastState = curState;
            Panel.Actions.updateMode('fan-mode', curState);
        }
    }
    isRunning() {
        return this.connectedPPD;
    }
    async start() {
        try {
            let xmlProfiles = Resources.File.DBus('net.hadess.PowerProfiles-0.10.1');
            this.powerProfilesProxy = new Gio.DBusProxy.makeProxyWrapper(xmlProfiles)(Gio.DBus.system, 'net.hadess.PowerProfiles', '/net/hadess/PowerProfiles');
            let xmlSignals = Resources.File.DBus('net.hadess.PowerProfilesSignals-0.10.1');
            this.powerProfilesSignalProxy = new Gio.DBusProxy.makeProxyWrapper(xmlSignals)(Gio.DBus.system, 'org.freedesktop.DBus.Properties', '/net/hadess/PowerProfiles');
            this.connectedPPD = true;
            this.getProfileNames();
            this.updateProfile(await this.powerProfilesProxy.ActiveProfile);
            this.powerProfilesSignalProxy.connectSignal("PropertiesChanged", (name = '', variant, profile) => {
                this.setProfileFromSignal(name, variant, profile);
            });
            Log.debug(`Power Profiles Daemon client started successfully.`);
        }
        catch (e) {
            Log.error(`Power Profile DBus initialization failed!`, e);
        }
    }
    stop() {
        Log.debug(`Stopping Profile DBus client...`);
        if (this.isRunning()) {
            this.connectedPPD = false;
            this.powerProfilesProxy = null;
            this.powerProfilesSignalProxy = null;
            this.lastState = null;
        }
    }
}
//# sourceMappingURL=profile_dbus.js.map