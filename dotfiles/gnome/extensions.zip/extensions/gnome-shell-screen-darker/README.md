# gnome-shell-screen-darker
Help you do a switch between a darker screen and brighter screen by one click.

## Installation
Gnome extension store:

https://extensions.gnome.org/extension/4304/screen-darker/

## How I made this extension
https://www.youtube.com/watch?v=Y6zpDF_Ug50
