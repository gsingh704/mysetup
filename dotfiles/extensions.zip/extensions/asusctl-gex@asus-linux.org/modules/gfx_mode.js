const Me = imports.misc.extensionUtils.getCurrentExtension();
const { main, popupMenu } = imports.ui;
const { Gio, GLib } = imports.gi;
const Log = Me.imports.modules.log;
const DBus = Me.imports.modules.gfx_mode_dbus;
var Client = class Client {
    constructor() {
        this.iGpuString = 'unknown';
        this.connector = new DBus.GfxMode();
        this.connected = false;
        Log.info(`Starting GfxMode client...`);
    }
    getGfxMode() {
        if (this.isRunning())
            return this.connector.getGfxMode();
    }
    getGpuPower() {
        if (this.isRunning()) {
            return this.connector.getGpuPower();
        }
    }
    getIGPU() {
        try {
            this.iGpuString = GLib.file_test('/sys/bus/pci/drivers/amdgpu', GLib.FileTest.EXISTS) ? 'amd' : 'intel';
        }
        catch (e) {
            this.iGpuString = 'intel';
        }
        Log.info(`Detected integrated GPU: ${this.iGpuString}`);
        return this.iGpuString;
    }
    getAcl(ven, idx) {
        return this.connector.getAcl(ven, idx);
    }
    isRunning() {
        return (this.connected && this.connector && this.connector.isRunning());
    }
    start() {
        this.connected = this.connector.start();
        if (this.connected)
            this.populatePopup();
    }
    stop() {
        Log.info(`Stopping GfxMode client...`);
        if (this.isRunning()) {
            this.connected = false;
            this.connector.stop();
        }
    }
    populatePopup() {
        var _a;
        if (!this.isRunning())
            return;
        ext.panelButton.indicator._indicatorLayout.add_child(ext.panelButton.indicator._binGpu);
        let vendor = (_a = this.getGfxMode()) !== null && _a !== void 0 ? _a : 5;
        let gpuPower = this.getGpuPower();
        let menu = main.panel.statusArea['asusctl-gex.panel'].menu;
        let menuIdx = 1;
        menu.addMenuItem(new popupMenu.PopupMenuItem('Graphics Mode', { hover: false, can_focus: false, style_class: 'headline gfx headline-label asusctl-gex-menu-item' }), 0);
        Log.info(`Current Graphics Mode is ${this.connector.gfxLabels[vendor]}`);
        if (typeof gpuPower !== 'undefined') {
            let gpuPowerItem = new popupMenu.PopupImageMenuItem(`dedicated GPU: ${this.connector.powerLabel[gpuPower]}`, Gio.icon_new_for_string(`${Me.path}/icons/scalable/dgpu-${this.connector.powerLabel[gpuPower]}.svg`), {
                hover: false,
                can_focus: false,
                style_class: `gpupower ${this.connector.powerLabel[gpuPower]} asusctl-gex-menu-item`
            });
            menu.addMenuItem(gpuPowerItem, menuIdx++);
            menu.addMenuItem(new popupMenu.PopupSeparatorMenuItem(), menuIdx++);
        }
        this.connector.gfxLabels.forEach((label) => {
            if (label === 'unknown')
                return;
            let labelMenu = label;
            if (labelMenu == 'vfio' || labelMenu == 'compute') {
                labelMenu = '↳ ' + labelMenu;
            }
            let menuItem = new popupMenu.PopupImageMenuItem(labelMenu, Gio.icon_new_for_string(`${Me.path}/icons/scalable/gpu-${label}.svg`), { style_class: `${label} gfx-mode ${this.iGpuString} asusctl-gex-menu-item` });
            let idx = this.connector.gfxLabels.indexOf(label);
            let acl = this.getAcl(vendor, idx);
            if (idx === vendor) {
                menuItem.style_class = `${menuItem.style_class} active asusctl-gex-menu-item`;
                menuItem.label.set_text(`${menuItem.label.text}  ✔`);
            }
            menu.addMenuItem(menuItem, menuIdx++);
            menuItem.sensitive = acl;
            menuItem.active = acl;
            menuItem.connect('activate', () => {
                if (this.connector.lastState == 1 && idx == 3)
                    this.connector.pollerDelayTicks = 5;
                this.connector.setGfxMode(idx);
            });
        });
        menu.addMenuItem(new popupMenu.PopupSeparatorMenuItem(), menuIdx++);
    }
}
//# sourceMappingURL=gfx_mode.js.map