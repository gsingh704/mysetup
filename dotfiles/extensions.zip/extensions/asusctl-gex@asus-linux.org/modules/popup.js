const Me = imports.misc.extensionUtils.getCurrentExtension();
var Menu = class Menu {
    constructor() {
    }
}
//# sourceMappingURL=popup.js.map