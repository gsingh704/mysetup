const Me = imports.misc.extensionUtils.getCurrentExtension();
const Log = Me.imports.modules.log;
const Panel = Me.imports.modules.panel;
const Resources = Me.imports.modules.resources;
const Gio = imports.gi.Gio;
var Profile = class Profile {
    constructor() {
        this.asusLinuxProxy = null;
        this.powerProfilesProxy = null;
        this.connectedPPD = false;
        this.connectedASUSD = false;
        this.lastState = null;
        this.profiles = [];
    }
    getProfileNames() {
        if (this.isRunning()) {
            try {
                let _profiles = this.powerProfilesProxy.Profiles;
                if (_profiles.length > 0) {
                    for (const [_key, value] of Object.entries(_profiles)) {
                        this.profiles[parseInt(_key)] = {
                            'Profile': value.Profile.unpack(),
                            'Driver': value.Driver.unpack()
                        };
                        Log.info(`Fetched Power Profile: ${value.Profile.unpack()}`);
                    }
                }
            }
            catch (e) {
                Log.error(`Power Profiles: failed to fetch profile names!`, e);
            }
        }
        return this.profiles;
    }
    setProfile(mode) {
        if (this.isRunning()) {
            try {
                this.powerProfilesProxy.ActiveProfile = mode;
                this.updateProfile(mode);
                return true;
            }
            catch (e) {
                Log.error(`Profile DBus set power profile failed!`, e);
            }
        }
    }
    updateProfile(curState = null) {
        if (curState && curState !== '' && this.lastState !== curState) {
            let message = `Power profile has changed to ${curState}`;
            if (this.lastState !== null) {
                Panel.Actions.notify(Panel.Title, message, `scalable/notification-${curState}.svg`);
            }
            this.lastState = curState;
            Panel.Actions.updateMode('fan-mode', curState);
        }
    }
    isRunning() {
        return this.connectedPPD;
    }
    async start() {
        try {
            let xml = Resources.File.DBus('net.hadess.PowerProfiles-0.9.0');
            this.powerProfilesProxy = new Gio.DBusProxy.makeProxyWrapper(xml)(Gio.DBus.system, 'net.hadess.PowerProfiles', '/net/hadess/PowerProfiles');
            this.connectedPPD = true;
            this.getProfileNames();
            this.updateProfile(await this.powerProfilesProxy.ActiveProfile);
            this.powerProfilesProxy.connectSignal("ProfileReleased", (proxy = null, profile) => {
                if (proxy) {
                    Log.info('Signal NotifyProfile triggered.');
                    Log.info(profile.toString());
                }
            });
            Log.info(`Power Profiles Daemon client started successfully.`);
        }
        catch (e) {
            Log.error(`Power Profile DBus initialization failed!`, e);
        }
        try {
            let xml = Resources.File.DBus('org-asuslinux-profile-4');
            this.asusLinuxProxy = new Gio.DBusProxy.makeProxyWrapper(xml)(Gio.DBus.system, 'org.asuslinux.Daemon', '/org/asuslinux/Profile');
            this.connectedASUSD = true;
            this.asusLinuxProxy.connectSignal("NotifyProfile", (proxy = null, name, data) => {
                if (proxy) {
                    Log.info('Signal NotifyProfile triggered.');
                    Log.info(name.toString());
                    Log.info(data.toString());
                }
            });
            Log.info(`asusctl Profiles Daemon client started successfully.`);
        }
        catch (e) {
            Log.error(`asusctl Profile DBus initialization failed!`, e);
        }
    }
    stop() {
        Log.info(`Stopping Profile DBus client...`);
        if (this.isRunning()) {
            this.connectedPPD = false;
            this.connectedASUSD = false;
            this.powerProfilesProxy = null;
            this.asusLinuxProxy = null;
            this.lastState = null;
        }
    }
}
//# sourceMappingURL=profile_dbus.js.map